import React, { useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

import Login from "./pages/Login";
import Register from "./pages/Register";

import Account from "./pages/Account/Account"
import EditAccount from "./pages/Account/EditAccount";

import Balance from "./pages/Balance/Balance";
import BalanceList from "./pages/Balance/BalanceList"
import CheckTopUpBalance from "./pages/Balance/CheckTopUpBalance";
import TopUpBalance from "./pages/Balance/TopUpBalance";
import TopUpReceipt from "./pages/Balance/TopUpReceipt";

import History from "./pages/History/History";
import PaymentReceipt from "./pages/History/PaymentReceipt";

import Home from "./pages/Menu/Home";
import Electric from "./pages/Menu/Electric";
import Internet from "./pages/Menu/Internet";
import Water from "./pages/Menu/Water";
import Pulse from "./pages/Menu/Pulse";
import Ewallet from "./pages/Menu/Ewallet";
import Data from "./pages/Menu/Data";
import FeeCheck from "./pages/Menu/FeeCheck";

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login" screenOptions={{headerShown: false}}>
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Register" component={Register} />

        <Stack.Screen name="Account" component={Account} />
        <Stack.Screen name="EditAccount" component={EditAccount} />

        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Electric" component={Electric} />
        <Stack.Screen name="Internet" component={Internet} />
        <Stack.Screen name="Water" component={Water} />
        <Stack.Screen name="Pulse" component={Pulse} />
        <Stack.Screen name="Ewallet" component={Ewallet} />
        <Stack.Screen name="Data" component={Data} />
        <Stack.Screen name="FeeCheck" component={FeeCheck} />

        <Stack.Screen name="History" component={History} />
        <Stack.Screen name="PaymentReceipt" component={PaymentReceipt} />

        <Stack.Screen name="Balance" component={Balance} />
        <Stack.Screen name="BalanceList" component={BalanceList} />
        <Stack.Screen name="TopUpBalance" component={TopUpBalance} />
        <Stack.Screen name="CheckTopUpBalance" component={CheckTopUpBalance} />
        <Stack.Screen name="TopUpReceipt" component={TopUpReceipt} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
































// import { StatusBar } from 'expo-status-bar';
// import { StyleSheet, Text, View } from 'react-native';

// export default function App() {
//   return (
//     <View style={styles.container}>
//       <Text>Open up App.js to start working on your app!</Text>
//       <StatusBar style="auto" />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
// });

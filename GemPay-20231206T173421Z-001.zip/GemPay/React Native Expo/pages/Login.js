import React, { useState } from "react";
import { View, StyleSheet, Text, Image, TextInput, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import * as yup from "yup";
import axios from "axios";

const validationSchema = yup.object().shape({
  username: yup.string().required("Harap Memasukkan Username"),
  password: yup.string().required("Harap Memasukkan Password"),
})

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});

  const navigation = useNavigation();

  const handleLoginGoogle = () => {
    navigation.navigate("Register") // masih salah sih
  }
  const handleLogIn = async () => {
    try {
      await validationSchema.validate({username, password}, {abortEarly: false});
      axios.get('http://localhost:5000/login?username=${username}&password=${password}')
        .then(response => {
          console.log("Response:", response.data)
          navigation.navigate("Home")
        })
        .catch(error => {
          console.error("Error:", error);
        });
    }
    catch (validationErrors) {
      const newErrors = {};
      validationErrors.inner.forEach(error => {
        newErrors[error.path] = error.message;
      });
      setErrors(newErrors);
    }
  }
  const handleLostPassword = () => {
    navigation.navigate("Register") // masih salah
  }

  return (
    <View style={styles.container}>
      {/* Title */}
      <View style={styles.titleBox}>
        <Text style={styles.title}>Login</Text>
      </View>

      {/* Button Login with Google */}
      <View style={styles.loginGoogleButtonBox}>
        <TouchableOpacity style={styles.loginGoogleButton} onPress={handleLoginGoogle}>
          <View style={styles.googleImageBox}>
            <Image style={styles.googleImage} source={require("../assets/google.png")} />
          </View>
          <View style={styles.loginGoogleTextBox}>
            <Text style={styles.loginGoogleText}>Login with Google</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* Text Or */}
      <View style={styles.orTextAndLineBox}>
        <View style={styles.line} />
        <View style={styles.orTextBox}>
          <Text style={styles.orText}>Or</Text>
        </View>
        <View style={styles.line} />
      </View>

      {/* Input Username */}
      <View style={styles.usernameInputAndLogoBox}>
        <View style={styles.usernameLogoBox}>
          <Image style={styles.usernameLogo} source={require("../assets/username.png")} />
        </View>
        <View style={styles.usernameInputBox}>
          <TextInput 
            style={styles.usernameInput}
            placeholder="Username"
            value={username}
            onChangeText={setUsername}
          />
        </View>
      </View>
      {errors.username && <Text style={{color: "red", fontSize: 12}}>{errors.username}</Text>}

      {/* Input Password */}
      <View style={styles.passwordInputAndLogoBox}>
        <View style={styles.passwordLogoBox}>
          <Image style={styles.passwordLogo} source={require("../assets/password.png")} />
        </View>
        <View style={styles.passwordInputBox}>
          <TextInput 
            style={styles.passwordInput}
            secureTextEntry
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
          />
        </View>
      </View>
      {errors.password && <Text style={{color: "red", fontSize: 12}}>{errors.password}</Text>}

      {/* Button Log In */}
      <View style={styles.logInButtonBox}>
        <TouchableOpacity style={styles.logInButton} onPress={handleLogIn}>
          <View style={styles.logInTextBox}>
            <Text style={styles.logInText}>Log In</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* Link Lost Your Password */}
      <View style={styles.lostPasswordLinkBox}>
        <TouchableOpacity style={styles.lostPasswordLink} onPress={handleLostPassword}>
          <View style={styles.lostPasswordTextBox}>
            <Text style={styles.lostPasswordText}>Lost Your Password?</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    display: "flex",
    justifyContent: "center",
    height: "100%",
    flexDirection: "column",
    padding: 20,
  },

  // Title
  titleBox: {
    display: "flex",
    justifyContent: "center",
    flexDirection: "row",
    backgroundColor: "#00ef99",
    marginHorizontal: 100,
    marginVertical: 8,
    paddingVertical: 8,
    borderRadius: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
  },

  // Button Login with Google
  loginGoogleButtonBox: {
    backgroundColor: "#77b7f3",
    marginVertical: 8,
    padding: 8,
    borderRadius: 10,
  },
  loginGoogleButton: {
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
  },
  googleImageBox: {
    backgroundColor: "white",
    padding: 4,
    borderRadius: 4,
  },
  googleImage: {
    height: 24,
    width: 24,
  },
  loginGoogleTextBox: {
    paddingHorizontal: 4,
  },
  loginGoogleText: {
    paddingHorizontal: 4,
  },

  // Text Or
  orTextAndLineBox: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    paddingVertical: 4,
    marginVertical: 4,
  },
  line: {
    backgroundColor: "black",
    width: "40%",
    height: 2,
  },
  orTextBox: {
    paddingHorizontal: 4,
  },
  orText: {
    paddingHorizontal: 4,
  },

  // Input Username
  usernameInputAndLogoBox: {
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    paddingVertical: 4,
    marginVertical: 4,
    borderColor: "black",
    borderRadius: 10,
    borderWidth: 1,
  },
  usernameLogoBox: {
    padding: 4,
  },
  usernameLogo: {
    width: 32,
    height: 32,
  },
  usernameInputBox: {
    paddingHorizontal: 4,
  },
  usernameInput: {
    paddingHorizontal: 4,
    width: 260,
  },
  
  // Input Password
  passwordInputAndLogoBox: {
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    paddingVertical: 4,
    marginVertical: 4,
    borderColor: "black",
    borderRadius: 10,
    borderWidth: 1,
  },
  passwordLogoBox: {
    padding: 4,
  },
  passwordLogo: {
    width: 32,
    height: 32,
  },
  passwordInputBox: {
    paddingHorizontal: 4,
  },
  passwordInput: {
    paddingHorizontal: 4,
    width: 260,
  },

  // Button Log In
  logInButtonBox: {
    display: "flex",
    justifyContent: "center",
    flexDirection: "row",
    backgroundColor: "#1d71be",
    marginVertical: 4,
    borderRadius: 10,
  },
  logInButton: {
    display: "flex",
    justifyContent: "center",
    flexDirection: "row",
    paddingVertical: 4,
    width: 280,
  },
  logInTextBox: {
    paddingVertical: 4,
  },
  logInText: {
    color: "white",
  },

  // Link Lost Your Account
  lostPasswordLinkBox: {
    display: "flex",
    justifyContent: "center",
    flexDirection: "row",
    marginVertical: 4,
  },
  lostPasswordLink: {
    display: "flex",
    justifyContent: "center",
    flexDirection: "row",
    paddingVertical: 4,
  },
  lostPasswordTextBox: {
    padding: 4,
  },
  lostPasswordText: {
    color: "black",
  },
});

export default Login;
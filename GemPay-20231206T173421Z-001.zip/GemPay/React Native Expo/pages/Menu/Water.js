import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Water = () => {
  return (
    <View>
      <Text>Salam dari Water</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default Water
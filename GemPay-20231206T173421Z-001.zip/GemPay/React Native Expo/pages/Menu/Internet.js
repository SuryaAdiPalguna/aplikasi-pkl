import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Internet = () => {
  return (
    <View>
      <Text>Salam dari Internet</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default Internet
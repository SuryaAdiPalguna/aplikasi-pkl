import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Data = () => {
  return (
    <View>
      <Text>Salam dari Data</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default Data
import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Pulse = () => {
  return (
    <View>
      <Text>Salam dari Pulse</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default Pulse
import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Ewallet = () => {
  return (
    <View>
      <Text>Salam dari Ewallet</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default Ewallet
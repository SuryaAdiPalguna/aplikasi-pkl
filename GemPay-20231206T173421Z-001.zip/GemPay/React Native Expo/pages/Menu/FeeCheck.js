import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const FeeCheck = () => {
  return (
    <View>
      <Text>Salam dari FeeCheck</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default FeeCheck
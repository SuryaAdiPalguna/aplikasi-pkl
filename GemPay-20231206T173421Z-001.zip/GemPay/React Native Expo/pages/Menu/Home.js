import React, { useState } from 'react'
import { ScrollView, View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useRoute } from '@react-navigation/native';

const Home = () => {
  const route = useRoute()

  const data = route.params?.data

  const [search, setSearch] = useState("")


  return (
    <View>
      <Text>Home</Text>
    </View>
  )
  // return (
  //   <View>
  //     {/* Navbar */}
  //     <View>
  //       {/* Header Navbar */}
  //       <View>
  //         {/* Logo */}
  //         <View>
  //           <Image />
  //         </View>

  //         {/* Username */}
  //         <TouchableOpacity>
  //           <View>
  //             {/* Foto */}
  //             <View>
  //               <Image />
  //             </View>

  //             {/* Nama Username */}
  //             <View>
  //               <Text>...</Text>
  //             </View>
  //           </View>
  //         </TouchableOpacity>
  //       </View>

  //       {/* Search */}
  //       <View>
  //         <View>
  //           <Image />
  //         </View>
  //         <View>
  //           <TextInput 
  //             placeholder="Cari Kontak dan Tagihan"
  //             value={search}
  //             onChangeText={setSearch}
  //           />
  //         </View>
  //       </View>
  //     </View>

  //     {/* Vertical Scroll */}
  //     <ScrollView horizontal={false}>
  //       {/* Judul Horizontal Scroll */}
  //       <View>
  //         <Text>Take Your Pick</Text>
  //       </View>

  //       {/* Horizontal Menu Scroll */}
  //       <ScrollView horizontal={true}>
  //         <TouchableOpacity>
  //           <View>
  //             <View>
  //               <Image />
  //             </View>

  //             <View>
  //               <Text></Text>
  //             </View>
  //           </View>
  //         </TouchableOpacity>

  //         <TouchableOpacity>
  //           <View>
  //             <View>
  //               <Image />
  //             </View>

  //             <View>
  //               <Text></Text>
  //             </View>
  //           </View>
  //         </TouchableOpacity>

  //         <TouchableOpacity>
  //           <View>
  //             <View>
  //               <Image />
  //             </View>

  //             <View>
  //               <Text></Text>
  //             </View>
  //           </View>
  //         </TouchableOpacity>

  //         <TouchableOpacity>
  //           <View>
  //             <View>
  //               <Image />
  //             </View>

  //             <View>
  //               <Text></Text>
  //             </View>
  //           </View>
  //         </TouchableOpacity>

  //         <TouchableOpacity>
  //           <View>
  //             <View>
  //               <Image />
  //             </View>

  //             <View>
  //               <Text></Text>
  //             </View>
  //           </View>
  //         </TouchableOpacity>
  //       </ScrollView>

  //       {/* Iklan */}
  //       <View>
  //         <Text>Iklan</Text>
  //       </View>

  //       {/* Judul Vertical Scroll */}
  //       <View>
  //         <Text></Text>
  //       </View>

  //       {/* Menu */}
  //       <View>
  //         <View>
  //           <TouchableOpacity>
  //             <View>
  //               <View>
  //                 <Image />
  //               </View>

  //               <View>
  //                 <Text></Text>
  //               </View>
  //             </View>
  //           </TouchableOpacity>

  //           <TouchableOpacity>
  //             <View>
  //               <View>
  //                 <Image />
  //               </View>

  //               <View>
  //                 <Text></Text>
  //               </View>
  //             </View>
  //           </TouchableOpacity>
  //         </View>
  //         <View>
  //           <TouchableOpacity>
  //             <View>
  //               <View>
  //                 <Image />
  //               </View>

  //               <View>
  //                 <Text></Text>
  //               </View>
  //             </View>
  //           </TouchableOpacity>

  //           <TouchableOpacity>
  //             <View>
  //               <View>
  //                 <Image />
  //               </View>

  //               <View>
  //                 <Text></Text>
  //               </View>
  //             </View>
  //           </TouchableOpacity>
  //         </View>
  //         <View>
  //           <TouchableOpacity>
  //             <View>
  //               <View>
  //                 <Image />
  //               </View>

  //               <View>
  //                 <Text></Text>
  //               </View>
  //             </View>
  //           </TouchableOpacity>

  //           <TouchableOpacity>
  //             <View>
  //               <View>
  //                 <Image />
  //               </View>

  //               <View>
  //                 <Text></Text>
  //               </View>
  //             </View>
  //           </TouchableOpacity>
  //         </View>
  //       </View>
  //     </ScrollView>

  //     {/* Footer */}
  //     <View>
  //       <TouchableOpacity>
  //         <View>
  //           <View>
  //             <Image />
  //           </View>

  //           <View>
  //             <Text></Text>
  //           </View>
  //         </View>
  //       </TouchableOpacity>

  //       <TouchableOpacity>
  //         <View>
  //           <View>
  //             <Image />
  //           </View>

  //           <View>
  //             <Text></Text>
  //           </View>
  //         </View>
  //       </TouchableOpacity>

  //       <TouchableOpacity>
  //         <View>
  //           <View>
  //             <Image />
  //           </View>

  //           <View>
  //             <Text></Text>
  //           </View>
  //         </View>
  //       </TouchableOpacity>

  //       <TouchableOpacity>
  //         <View>
  //           <View>
  //             <Image />
  //           </View>

  //           <View>
  //             <Text></Text>
  //           </View>
  //         </View>
  //       </TouchableOpacity>

  //       <TouchableOpacity>
  //         <View>
  //           <View>
  //             <Image />
  //           </View>

  //           <View>
  //             <Text></Text>
  //           </View>
  //         </View>
  //       </TouchableOpacity>
  //     </View>
  //   </View>
  // )
}

const styles = StyleSheet.create({})

export default Home
import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Electric = () => {
  return (
    <View>
      <Text>Salam dari Electric</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default Electric
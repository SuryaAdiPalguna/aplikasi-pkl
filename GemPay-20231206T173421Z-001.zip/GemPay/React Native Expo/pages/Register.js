import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Register = () => {
  return (
    <View style={styles.container}>
      <Text>Salam dari Register</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    fontSize: 80,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100%"
  }
})

export default Register
import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Balance = () => {
  return (
    <View>
      <Text>Salam dari Balance</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default Balance
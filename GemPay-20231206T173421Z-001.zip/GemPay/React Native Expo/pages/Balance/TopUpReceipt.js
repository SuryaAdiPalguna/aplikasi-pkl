import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const TopUpReceipt = () => {
  return (
    <View>
      <Text>Salam dari TopUpReceipt</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default TopUpReceipt
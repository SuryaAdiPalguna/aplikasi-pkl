import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const CheckTopUpBalance = () => {
  return (
    <View>
      <Text>Salam dari CheckTopUpBalance</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default CheckTopUpBalance
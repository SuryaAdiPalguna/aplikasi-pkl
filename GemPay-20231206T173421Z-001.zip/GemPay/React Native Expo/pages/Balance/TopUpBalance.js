import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const TopUpBalance = () => {
  return (
    <View>
      <Text>Salam dari TopUpBalance</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default TopUpBalance
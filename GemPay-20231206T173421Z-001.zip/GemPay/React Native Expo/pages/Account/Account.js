import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const Account = () => {
  return (
    <View>
      {/* Background yang Biru-Biru */}
      <View>
        
      </View>

      {/* Background yang Putih-Putih */}
      <View></View>
    </View>
  )
}

const styles = StyleSheet.create({})

export default Account
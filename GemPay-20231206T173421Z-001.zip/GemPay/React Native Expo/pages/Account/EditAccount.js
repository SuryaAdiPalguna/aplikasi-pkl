import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const EditAccount = () => {
  return (
    <View>
      <Text>Salam dari EditAccount</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default EditAccount
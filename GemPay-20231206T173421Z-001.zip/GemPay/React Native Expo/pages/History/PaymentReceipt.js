import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

const PaymentReceipt = () => {
  return (
    <View>
      <Text>Salam dari PaymentReceipt</Text>
    </View>
  )
}

const styles = StyleSheet.create({})

export default PaymentReceipt